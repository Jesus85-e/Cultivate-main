export interface BookInterface {
  titulo?: string;
  idioma?: string;
  descripcion?: string;
  portada?: string;
  precio?: string;
  link_amazon?: string;
  autor?: string;
  oferta?: string;
  id?: string;
  userUid?: string;
}